from django.apps import AppConfig


class HugmetaskerappConfig(AppConfig):
    name = 'hugmetaskerapp'
